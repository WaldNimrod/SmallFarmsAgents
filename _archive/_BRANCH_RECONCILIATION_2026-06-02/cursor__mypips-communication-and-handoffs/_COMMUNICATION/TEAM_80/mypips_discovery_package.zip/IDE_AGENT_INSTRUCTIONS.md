# IDE / Agent Instructions — MyPIPS Discovery

## Objective
Run the script to discover active public pages under mypips.app

## Environment Setup
1. Create virtual environment
   python -m venv .venv

2. Activate
   mac/linux:
   source .venv/bin/activate

   windows:
   .venv\Scripts\activate

3. Install dependencies
   pip install -r requirements.txt

## Running the script
Basic run:
python mypips_discover.py --seeds mypips_seeds_example.txt --hebrew --english --workers 4 --delay 1.0 --years --max 3000

## Output
- mypips_scan.csv → all attempts
- mypips_active.txt → only active pages

## Tuning
- Increase coverage:
  increase --max
  add more seeds

- Be respectful:
  keep workers <= 6
  delay >= 0.8

## Extension ideas
- expand seed list dynamically
- add domain-specific words
- integrate results into DB

## Expected behavior
Agent should:
1. Run script
2. Collect results
3. Return active URLs
4. Optionally enrich dataset
