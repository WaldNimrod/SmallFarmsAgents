#!/usr/bin/env python3
"""
mypips_discover.py

Discovers likely active public pages under https://mypips.app/<slug>

Strategy:
1. Generate candidate slugs from:
   - built-in Hebrew/English seed words
   - optional custom wordlist
   - optional permutations
2. Request candidate URLs with conservative rate limiting
3. Consider a page "active" when:
   - HTTP 200
   - non-trivial body length
   - body does not match common "not found" markers
4. Save results to CSV and TXT

Usage examples:
    python mypips_discover.py --seeds seeds.txt --out found.csv
    python mypips_discover.py --hebrew --english --max 5000
    python mypips_discover.py --seeds seeds.txt --workers 6 --delay 0.6

Notes:
- Respect the site's terms, robots, and infrastructure.
- Keep concurrency and request rate modest.
- This script does NOT brute-force arbitrary deep paths; only single-slug pages.
"""

from __future__ import annotations

import argparse
import asyncio
import csv
import random
import re
import sys
import unicodedata
from pathlib import Path
from typing import Iterable, List, Set, Tuple
from urllib.parse import quote

import aiohttp

BASE_URL = "https://mypips.app"

DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; research-script/1.0; +https://example.invalid)",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "he,en;q=0.9,en-US;q=0.8",
}

NOT_FOUND_MARKERS = [
    "404",
    "not found",
    "page not found",
    "cannot find",
    "לא נמצא",
    "העמוד לא נמצא",
]

HEBREW_SEEDS = [
    "nimrod", "garden", "farm", "organic", "veggies", "vegetables",
    "משק", "הגינה", "גינה", "חווה", "אורגני", "ירקות", "חקלאי",
    "שדה", "מושב", "משלוח", "ירוק", "טבע", "תוצרת", "שוק", "סל",
]

ENGLISH_SEEDS = [
    "farm", "organic", "garden", "veggie", "vegetable", "greens",
    "market", "shop", "fresh", "field", "produce", "basket", "box",
]


def slugify(text: str) -> str:
    text = text.strip()
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", text)
    text = text.replace("_", "-").replace(" ", "-")
    text = re.sub(r"-{2,}", "-", text)
    text = re.sub(r"[^0-9A-Za-z\u0590-\u05FF\-]", "", text)
    return text.strip("-").lower()


def load_lines(path: Path) -> List[str]:
    if not path.exists():
        raise FileNotFoundError(path)
    lines = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        s = raw.strip()
        if not s or s.startswith("#"):
            continue
        lines.append(s)
    return lines


def build_candidates(
    custom_seeds: Iterable[str],
    use_hebrew: bool,
    use_english: bool,
    numeric_suffixes: int,
    years: bool,
) -> List[str]:
    seeds: Set[str] = set()

    for s in custom_seeds:
        ss = slugify(s)
        if ss:
            seeds.add(ss)

    if use_hebrew:
        for s in HEBREW_SEEDS:
            ss = slugify(s)
            if ss:
                seeds.add(ss)

    if use_english:
        for s in ENGLISH_SEEDS:
            ss = slugify(s)
            if ss:
                seeds.add(ss)

    # Variants
    variants: Set[str] = set(seeds)
    for s in list(seeds):
        variants.add(s.replace("-", ""))
        if "-" not in s and len(s) > 4:
            variants.add(f"{s}-farm")
            variants.add(f"{s}-garden")
            variants.add(f"{s}-organic")
            variants.add(f"{s}-shop")

    if numeric_suffixes > 0:
        for s in list(variants):
            for i in range(1, numeric_suffixes + 1):
                variants.add(f"{s}{i}")
                variants.add(f"{s}-{i}")

    if years:
        for s in list(variants):
            for y in ("2023", "2024", "2025", "2026"):
                variants.add(f"{s}{y}")
                variants.add(f"{s}-{y}")

    # Filter junk
    candidates = sorted({v for v in variants if 2 <= len(v) <= 60})
    random.shuffle(candidates)
    return candidates


def is_likely_active(status: int, text: str) -> bool:
    if status != 200:
        return False
    body = (text or "").strip().lower()
    if len(body) < 400:
        return False
    for marker in NOT_FOUND_MARKERS:
        if marker in body[:5000]:
            return False
    return True


async def fetch_one(
    session: aiohttp.ClientSession,
    slug: str,
    timeout_s: float,
) -> Tuple[str, int, int, bool, str]:
    url = f"{BASE_URL}/{quote(slug)}"
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=timeout_s), allow_redirects=True) as resp:
            text = await resp.text(errors="ignore")
            active = is_likely_active(resp.status, text)
            title = ""
            m = re.search(r"<title>(.*?)</title>", text, re.IGNORECASE | re.DOTALL)
            if m:
                title = re.sub(r"\s+", " ", m.group(1)).strip()
            return url, resp.status, len(text), active, title
    except Exception:
        return url, 0, 0, False, ""


async def run_scan(
    candidates: List[str],
    workers: int,
    delay: float,
    timeout_s: float,
    max_count: int | None,
) -> List[Tuple[str, int, int, bool, str]]:
    sem = asyncio.Semaphore(workers)
    results: List[Tuple[str, int, int, bool, str]] = []

    connector = aiohttp.TCPConnector(limit=workers, ssl=False)

    async with aiohttp.ClientSession(headers=DEFAULT_HEADERS, connector=connector) as session:
        async def bounded(slug: str):
            async with sem:
                res = await fetch_one(session, slug, timeout_s)
                await asyncio.sleep(delay)
                return res

        subset = candidates[:max_count] if max_count else candidates
        tasks = [asyncio.create_task(bounded(slug)) for slug in subset]
        for coro in asyncio.as_completed(tasks):
            res = await coro
            results.append(res)
            url, status, size, active, title = res
            flag = "ACTIVE" if active else "----"
            print(f"{flag} {status:3} {size:6} {url} {title}", flush=True)

    return results


def save_results(results, out_csv: Path, out_txt: Path):
    active_rows = [r for r in results if r[3]]

    with out_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["url", "status", "body_len", "active", "title"])
        writer.writerows(results)

    with out_txt.open("w", encoding="utf-8") as f:
        for url, status, size, active, title in active_rows:
            line = url
            if title:
                line += f" | {title}"
            f.write(line + "\n")

    print()
    print(f"Saved full scan to:  {out_csv}")
    print(f"Saved active only to: {out_txt}")
    print(f"Active pages found:   {len(active_rows)}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", type=str, help="Path to custom seed list (one per line)")
    parser.add_argument("--hebrew", action="store_true", help="Include built-in Hebrew seeds")
    parser.add_argument("--english", action="store_true", help="Include built-in English seeds")
    parser.add_argument("--numeric-suffixes", type=int, default=2, help="Generate suffixes 1..N")
    parser.add_argument("--years", action="store_true", help="Append year variants")
    parser.add_argument("--workers", type=int, default=5, help="Concurrent workers")
    parser.add_argument("--delay", type=float, default=0.8, help="Delay after each request per worker")
    parser.add_argument("--timeout", type=float, default=12.0, help="Per-request timeout in seconds")
    parser.add_argument("--max", type=int, default=None, help="Max candidate count to test")
    parser.add_argument("--out", type=str, default="mypips_scan.csv", help="CSV output path")
    parser.add_argument("--out-active", type=str, default="mypips_active.txt", help="TXT output path")
    args = parser.parse_args()

    custom_seeds: List[str] = []
    if args.seeds:
        custom_seeds = load_lines(Path(args.seeds))

    if not args.hebrew and not args.english and not custom_seeds:
        print("No seed source selected. Use --hebrew and/or --english and/or --seeds FILE.", file=sys.stderr)
        return 2

    candidates = build_candidates(
        custom_seeds=custom_seeds,
        use_hebrew=args.hebrew,
        use_english=args.english,
        numeric_suffixes=args.numeric_suffixes,
        years=args.years,
    )

    print(f"Candidate count: {len(candidates)}")
    results = asyncio.run(
        run_scan(
            candidates=candidates,
            workers=max(1, args.workers),
            delay=max(0.0, args.delay),
            timeout_s=max(1.0, args.timeout),
            max_count=args.max,
        )
    )
    save_results(results, Path(args.out), Path(args.out_active))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
