# MyPIPS Discovery Package
Generated: 2026-04-03

## What this does
Scans for likely active public pages under:
https://mypips.app/<slug>

## Files
- mypips_discover.py — main scanner
- mypips_seeds_example.txt — seed list
- requirements.txt — dependencies
- IDE_AGENT_INSTRUCTIONS.md — step-by-step for running in IDE/agent

## Quick start
python -m venv .venv
source .venv/bin/activate  (Windows: .venv\Scripts\activate)
pip install -r requirements.txt

python mypips_discover.py --seeds mypips_seeds_example.txt --hebrew --english --workers 4 --delay 1.0 --years --max 3000
